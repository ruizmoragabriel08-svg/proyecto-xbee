# Script Python receptor en modo AT
