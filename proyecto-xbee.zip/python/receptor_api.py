# Script Python receptor en modo API
