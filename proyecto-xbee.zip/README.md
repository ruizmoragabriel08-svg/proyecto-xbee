# Proyecto de Monitoreo de Temperatura con XBee

## 🎯 Objetivo
Implementar un sistema de sensor inalámbrico de temperatura utilizando módulos **XBee** y herramientas básicas de almacenamiento de información para el monitoreo de variables de temperatura en las **Unidades Tecnológicas de Santander (UTS)**.

## 📂 Estructura
- /arduino → códigos Arduino para el emisor
- /python → scripts Python para el coordinador
- /docs → documentación y diagramas
